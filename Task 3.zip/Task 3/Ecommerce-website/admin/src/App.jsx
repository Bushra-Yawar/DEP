import Navbar from "./components/Navbar/Navbar";
import Admin from "./Pages/Admin/Admin";

export default function App() {
  return (
    <div>
      <Navbar />
      <Admin />
    </div>
  )
}
