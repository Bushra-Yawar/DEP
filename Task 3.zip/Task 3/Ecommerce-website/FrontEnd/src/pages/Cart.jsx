import CartItems from '../components/CartItems/CartItems';

export default function Cart() {
  return (
    <div className="cart">
      <CartItems />
    </div>
  )
}
