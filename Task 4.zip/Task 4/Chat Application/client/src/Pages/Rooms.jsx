
import RoomList from '../components/RoomList';
export default function Rooms() {
  return (
    <div>
      <RoomList />
    </div>
  )
}
